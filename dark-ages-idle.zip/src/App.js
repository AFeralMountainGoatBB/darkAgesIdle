import logo from './logo.svg';
import React, { button, useEffect, useMemo, useState, useContext, useRef } from "react";
import InfoGrid from './components/InfoGrid.js'
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import './App.css';

function App() {
  const [peasantValue, setPeasantValue] = useState(0);
  const peasantValueRef = useRef(peasantValue);
  peasantValueRef.current=peasantValue;
  const [foodValue, setfoodValue] = useState(1);
  const [valuethree, setvaluethree] = useState(2);
  const [tickingBool, setTickBool]=useState(false);

  function handleOnClickOne(){
    setPeasantValue(peasantValue+1);
    if (!tickingBool)
    {
      constantTick();
      setTickBool(true);
    }
  }

  function constantTick(){
    setPeasantValue(peasantValueRef.current+1);
    console.log("tick");
    setTimeout(constantTick, 1000);
    // setTimeout(()=>{setPeasantValue(peasantValue+1)}, 1000);
  }
  
  return (
    <div className="App" style={{textAlign:"center"}}>
        <InfoGrid value1={peasantValue} value2={foodValue} value3={valuethree} function1={handleOnClickOne()}></InfoGrid>
        <Button onClick={handleOnClickOne}>testButton</Button>
    </div>
  );
}

export default App;
